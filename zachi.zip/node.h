#include "graph.h"
void insert_node_cmd(pnode *head);
void delete_node_cmd(pnode *head);