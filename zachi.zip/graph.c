#include "graph.h"
#include <stdio.h>
#include"node.h"
#include"edges.h"

int input;  //get from the user
int vertex; //the number of the vertex
int edgeto; //int that store the vetex that the edge go to
int weightedge; //weight of the edge
char menu[1];
printf("Enter a character: ");
scanf(" %c", &menu[0]);


//pnode -> pointer to struct of node, head pointer to pointer
if (menu[0] == 'A') {   
    build_graph_cmd(pnode *head){
    if (*head != NULL)
    {
        //then there is a graph at this addres already
        deleteGraph_cmd(pnode *head);
    }  
    while (scanf("%d",input) !=0 && != EOF)
    {
        if (input == n)
        {
            //***insert this node***//
            insert_node_cmd()

        }
        while(keep)
        
    }
    
    i
    
  





    }
}

