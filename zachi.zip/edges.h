void deletedge(int weight);
void addedge (int weight, struct pnode* endpoint);